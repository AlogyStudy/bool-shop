<?php

// config.inc.php
// 配置文件
defined('ACC') || exit('ACC Denied');

$_CFG = array();


$_CFG['host'] = 'localhost';
$_CFG['user'] = 'root';
$_CFG['pwd'] = ''; 
$_CFG['db'] = 'boolshop';
$_CFG['char'] = 'utf8';


?>
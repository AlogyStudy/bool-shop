<meta charset="UTF-8" />
<?php
	
	define('ACC', true);
	
	require('./include/init.php');
	
	$test = new TestModel();
	
	$test->reg(array('t1' => 'frontuser', 't2' => 'frontuser'));

?>
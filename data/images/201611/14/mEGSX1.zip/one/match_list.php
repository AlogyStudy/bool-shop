<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
 <HEAD>
  <TITLE> 比赛列表 </TITLE>
  <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8" />
 </HEAD>
 <BODY>

 <h1>比赛列表信息公告</h1>
 <table>
 <tr>
 <th>比赛时间</th>
 <th>比赛队员1</th>
 <th>比赛结果</th>
 <th>比赛队员2</th>
 </tr>
<?php
//得到所有的比赛信息
mysql_connect('127.0.0.1:3306', 'root', '123456');
mysql_query('set names utf8');
mysql_query('use itcast');
$sql = "select p1.id as p1_id, p2.id as p2_id, m.match_time, p1.stu_name as p1_name, m.match_result, p2.stu_name as p2_name from select_match as m left join select_student as p1 on m.player_1=p1.id left join select_student as p2 on m.player_2=p2.id";
$result = mysql_query($sql);

while($row = mysql_fetch_assoc($result)) {
?>
 <tr>
 <td><?php echo $row['match_time'];?></td>
 <td><?php echo $row['p1_name'];?></td>
 <td><?php echo $row['match_result'];?></td>
 <td><?php echo $row['p2_name'];?></td>
 </tr>
<?php 
}
?>
 
 </table>
  
 </BODY>
</HTML>